package com.example.seedgo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class registro : AppCompatActivity() {
        private lateinit var previewView: PreviewView
        private lateinit var imageCapture: ImageCapture

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_registro)

            // 👉 Depois do setContentView
            val btnVoltar = findViewById<Button>(R.id.btnVoltar)
            btnVoltar.setOnClickListener {
                finish()
            }

            previewView = findViewById(R.id.previewView)
            val btnCapturar = findViewById<Button>(R.id.btnCapturar)

            // Solicitar permissão
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }

            // Botão tirar foto
            btnCapturar.setOnClickListener {
                tirarFoto()
            }
        }

        private fun allPermissionsGranted() =
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED

        private val requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if (granted) startCamera()
                else Toast.makeText(this, "Permissão da câmera negada", Toast.LENGTH_SHORT).show()
            }

        private fun startCamera() {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                imageCapture = ImageCapture.Builder().build()

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        this, cameraSelector, preview, imageCapture
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "Erro ao iniciar a câmera", Toast.LENGTH_SHORT).show()
                }
            }, ContextCompat.getMainExecutor(this))
        }

        private fun tirarFoto() {
            val imageCapture = imageCapture ?: return

            val photoFile = File(
                externalMediaDirs.first(),
                "foto_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
            )

            val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

            imageCapture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onError(exc: ImageCaptureException) {
                        Toast.makeText(
                            applicationContext,
                            "Erro ao salvar a foto",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        Toast.makeText(
                            applicationContext,
                            "Foto salva em: ${photoFile.path}",
                            Toast.LENGTH_LONG
                        ).show()

                        finish() // volta para a tela anterior
                    }
                }
            )
        }
    }