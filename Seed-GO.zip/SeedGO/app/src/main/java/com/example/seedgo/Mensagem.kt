package com.example.seedgo

data class Mensagem(
    val texto: String,
    val enviada: Boolean

    )
