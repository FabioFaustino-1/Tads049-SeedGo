package com.example.seedgo
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val mensagens: MutableList<Mensagem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TIPO_ENVIADA = 1
    private val TIPO_RECEBIDA = 2

    override fun getItemViewType(position: Int): Int {
        return if (mensagens[position].enviada) TIPO_ENVIADA else TIPO_RECEBIDA
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TIPO_ENVIADA) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_msg_enviada, parent, false)
            EnviadaViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_msg_recebida, parent, false)
            RecebidaViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = mensagens[position]
        if (holder is EnviadaViewHolder)
            holder.bind(msg)
        else if (holder is RecebidaViewHolder)
            holder.bind(msg)
    }

    override fun getItemCount() = mensagens.size

    fun adicionarMensagem(msg: Mensagem) {
        mensagens.add(msg)
        notifyItemInserted(mensagens.size - 1)
    }

    inner class EnviadaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(m: Mensagem) {
            (itemView as TextView).text = m.texto
        }
    }

    inner class RecebidaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(m: Mensagem) {
            (itemView as TextView).text = m.texto
        }
    }
}