package com.example.seedgo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CadastroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.Cadastro)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val cpfCad = findViewById<EditText>(R.id.cpfCad)
        val nomeCad = findViewById<EditText>(R.id.nomeCad)
        val senhaCad = findViewById<EditText>(R.id.SenhaCad)
        val confirsencad = findViewById<EditText>(R.id.confirsenCad)
        val btncriaconta = findViewById<Button>(R.id.btncriaconta)


        btncriaconta.setOnClickListener {

            val cpf = cpfCad.text.toString().trim()
            val nome = nomeCad.text.toString().trim()
            val senha = senhaCad.text.toString().trim()
            val confirsen = confirsencad.text.toString().trim()


            if (cpf.isEmpty()) {
                cpfCad.error = "Insira o cpf"
                return@setOnClickListener
            }
            if (cpf.length != 11) {
                cpfCad.error = "insira um cpf válido"
                return@setOnClickListener
            }
            if (nome.isEmpty()) {
                nomeCad.error = "Insira o cpf"
                return@setOnClickListener
            }
            if (senha.isEmpty()) {
                senhaCad.error = "Insira o cpf"
                return@setOnClickListener
            }
            if (senha.length < 8) {
                senhaCad.error = "insira ao menos 8 caracteres"
                return@setOnClickListener
            }
            if (confirsen.isEmpty()) {
                confirsencad.error = "Confirme a senha"
                return@setOnClickListener
            }
            if (confirsen != senha) {
                confirsencad.error = "Senha não confere"
                return@setOnClickListener
            }

                // SALVAR NO SharedPreferences
            val prefs = getSharedPreferences("usuarios", MODE_PRIVATE)
            val editor = prefs.edit()

            editor.putString("cpf", cpf)
            editor.putString("nome", nome)
            editor.putString("senha", senha)

            editor.apply()
            Toast.makeText(this, "Cadastro salvo", Toast.LENGTH_SHORT).show()
            btncriaconta.setOnClickListener() {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            finish()
        }
    }
}