package com.example.seedgo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.inicio)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val platas = findViewById<ImageButton>(R.id.planacoe)
        platas.setOnClickListener {
            intent = Intent(this, plantacoes::class.java)
            startActivity(intent)
        }
        val contas = findViewById<ImageButton>(R.id.btnCont)
        contas.setOnClickListener {
            intent = Intent(this, chat::class.java)
            startActivity(intent)
        }

        val registras = findViewById<ImageButton>(R.id.registbtn)
        registras.setOnClickListener {
            intent = Intent(this, registro::class.java)
            startActivity(intent)
        }

        val configa = findViewById<ImageButton>(R.id.config)
        configa.setOnClickListener {
            intent = Intent(this, configuracoes::class.java)
            startActivity(intent)
        }


    }
}