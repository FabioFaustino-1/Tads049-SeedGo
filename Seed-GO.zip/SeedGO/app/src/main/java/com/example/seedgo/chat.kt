package com.example.seedgo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class chat : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var edt: EditText
    private lateinit var btn: Button

    private val mensagens = mutableListOf<Mensagem>()
    private lateinit var adapterChat: ChatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // Inicialização dos componentes
        recycler = findViewById(R.id.recyclerChat)
        edt = findViewById(R.id.edtMensagem)
        btn = findViewById(R.id.btnEnviar)

        adapterChat = ChatAdapter(mensagens)
        recycler.adapter = adapterChat
        recycler.layoutManager = LinearLayoutManager(this)

        btn.setOnClickListener {
            val texto = edt.text.toString().trim()

            if (texto.isNotEmpty()) {

                // Adiciona a mensagem enviada
                adapterChat.adicionarMensagem(
                    Mensagem(texto, true)
                )

                // Rola para o fim
                recycler.scrollToPosition(mensagens.size - 1)

                edt.text.clear()

                // Resposta automática
                recycler.postDelayed({

                    adapterChat.adicionarMensagem(
                        Mensagem("Resposta automática: $texto", false)
                    )

                    recycler.scrollToPosition(mensagens.size - 1)

                }, 800)
            }
        }
    }
}