package com.example.seedgo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btnLogin = findViewById<Button>(R.id.btncriaconta)
        val btnCad = findViewById<Button>(R.id.btnCad)
        val edtCpf = findViewById<EditText>(R.id.edtCpf)
        val edtSenha = findViewById<EditText>(R.id.edtSenha)
        btnCad.setOnClickListener{
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }


        btnLogin.setOnClickListener{
            val cpfDigitado = edtCpf.text.toString().trim()
            val senhaDigitada = edtSenha.text.toString().trim()

            val prefs = getSharedPreferences("usuarios", MODE_PRIVATE)

            val cpfSalvo = prefs.getString("cpf", null)
            val senhaSalva = prefs.getString("senha", null)
            val cpf = edtCpf.text.toString().trim()
            val senha = edtSenha.text.toString().trim()


            if(cpf.isEmpty()){
                edtCpf.error = "Digite o Cpf"
                return@setOnClickListener
            }

            if(senha.isEmpty()){
                edtSenha.error = "Digite a senha"
                return@setOnClickListener
            }

            if (!cpf.all { it.isDigit() }) {
                edtCpf.error = "Digite somente números"
                return@setOnClickListener
            }

            if (cpf.length != 11) {
                edtCpf.error = "CPF deve ter 11 dígitos"
                return@setOnClickListener
            }

            if (cpfDigitado != cpfSalvo) {
                edtCpf.error = "CPF não encontrado"
                return@setOnClickListener
            }

            if (senhaDigitada != senhaSalva) {
                edtSenha.error = "Senha incorreta"
                return@setOnClickListener
            }


            Toast.makeText(this, "Login realizado!", Toast.LENGTH_SHORT).show()


            val intent = Intent(this, inicio::class.java)
            startActivity(intent)
        }

    }
}