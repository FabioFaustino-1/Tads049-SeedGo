package com.seedgo.repository;
import com.seedgo.model.Agricultor;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AgricultorRepository extends JpaRepository<Agricultor,Integer>{}
